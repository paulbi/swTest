﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Smartwyre.DeveloperTest.Calculators;
using Smartwyre.DeveloperTest.Data;
using Smartwyre.DeveloperTest.Services;
using Smartwyre.DeveloperTest.Types;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Smartwyre.DeveloperTest.Runner;

class Program
{
    static RebateService rebateService;
    static void Main(string[] args)
    {
        var host = Host.CreateDefaultBuilder()
            .ConfigureServices((context, services) =>
            {

                services.AddTransient<IRebateDataStore, RebateDataStore>();
                services.AddTransient<IProductDataStore, ProductDataStore>();

                services.AddTransient<IRebateCalculator, FixedRateRebateCalculator>();
                services.AddTransient<IRebateCalculator, FixedCashAmountCalculator>();
                services.AddTransient<IRebateCalculator, AmountPerUomCalculator>();

                services.AddSingleton<IDictionary<SupportedIncentiveType, IRebateCalculator>>(serviceProvider =>
                {
                    var rebateCalculators = serviceProvider.GetServices<IRebateCalculator>();

                    return rebateCalculators.ToDictionary(
                        calculator => (SupportedIncentiveType)calculator.GetType().GetProperty("IncentiveType").GetValue(calculator),
                        calculator => calculator);
                });
            }).Build();

        rebateService = ActivatorUtilities.CreateInstance<RebateService>(host.Services);

        Test1();
        Test2();
        Test3();

        Console.ReadLine();
    }

    private static void Test1()
    {
        var request1 = new CalculateRebateRequest
        {
            ProductIdentifier = "1",
            RebateIdentifier = "1",
            Volume = 100
        };

        var result1 = rebateService.Calculate(request1);

        Console.WriteLine($"Expected result = 'true', success = {result1.Success}");
    }

    private static void Test2()
    {
        var request1 = new CalculateRebateRequest
        {
            ProductIdentifier = "3",
            RebateIdentifier = "2",
            Volume = 101
        };

        var result1 = rebateService.Calculate(request1);

        Console.WriteLine($"Expected result = 'true', success = {result1.Success}");
    }

    private static void Test3()
    {
        var request1 = new CalculateRebateRequest
        {
            ProductIdentifier = "2",
            RebateIdentifier = "2",
            Volume = 101
        };

        var result1 = rebateService.Calculate(request1);

        Console.WriteLine($"Expected result = 'false', success = {result1.Success}");
    }
}

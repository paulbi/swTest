using System;
using Xunit;

namespace Smartwyre.DeveloperTest.Tests;

public class PaymentServiceTests
{
    [Fact]
    public void Test1()
    {
        throw new NotImplementedException();
    }
}

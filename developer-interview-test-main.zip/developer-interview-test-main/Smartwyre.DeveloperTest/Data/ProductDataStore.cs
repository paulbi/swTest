﻿using Smartwyre.DeveloperTest.Types;
using System;

namespace Smartwyre.DeveloperTest.Data;

public class ProductDataStore : IProductDataStore
{
    public Product GetProduct(string productIdentifier)
    {
        // Access database to retrieve account, code removed for brevity 

        switch (productIdentifier) {
            case "1":
                {
                    return new Product
                    {
                        Id = 1,
                        Identifier = productIdentifier,
                        Price = 2.99m,
                        Uom = Guid.NewGuid().ToString(),
                        SupportedIncentives = SupportedIncentiveType.FixedRateRebate | SupportedIncentiveType.FixedCashAmount
                    };
                }
            case "2":
                {
                    return new Product
                    {
                        Id = 2,
                        Identifier = productIdentifier,
                        Price = 10.99m,
                        Uom = Guid.NewGuid().ToString(),
                        SupportedIncentives = SupportedIncentiveType.AmountPerUom
                    };
                }
            case "3":
                {
                    return new Product
                    {
                        Id = 3,
                        Identifier = productIdentifier,
                        Price = 65.02m,
                        Uom = Guid.NewGuid().ToString(),
                        SupportedIncentives = SupportedIncentiveType.FixedCashAmount
                    };
                }
        }

        return new Product();

    }
}

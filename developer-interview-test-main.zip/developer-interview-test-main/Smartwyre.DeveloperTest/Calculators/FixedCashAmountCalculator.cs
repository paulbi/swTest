﻿using Smartwyre.DeveloperTest.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smartwyre.DeveloperTest.Calculators
{
    public class FixedCashAmountCalculator : IRebateCalculator
    {
        public SupportedIncentiveType IncentiveType => SupportedIncentiveType.FixedCashAmount;
        public decimal Calculate(Rebate rebate, Product product, decimal volume)
        {
            return rebate.Amount;
        }
    }
}

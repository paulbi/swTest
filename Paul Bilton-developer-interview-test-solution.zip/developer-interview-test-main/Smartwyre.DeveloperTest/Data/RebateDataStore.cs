﻿using Smartwyre.DeveloperTest.Types;

namespace Smartwyre.DeveloperTest.Data;

public class RebateDataStore : IRebateDataStore
{
    public Rebate GetRebate(string rebateIdentifier)
    {
        var rebate = new Rebate()
        {
            Identifier = rebateIdentifier,
            Amount = 10,
            Percentage = 10,
        };

        switch (rebateIdentifier)
        {
            case "1":
                {
                    rebate.Incentive = SupportedIncentiveType.FixedRateRebate;
                    break;
                }
            case "2":
                {
                    rebate.Incentive = SupportedIncentiveType.AmountPerUom;
                    break;
                }
            case "3":
                {
                    rebate.Incentive = SupportedIncentiveType.FixedCashAmount;
                    break;
                }
            default: 
                { 
                    return null; 
                }
        }

        return rebate;
    }

    public void StoreCalculationResult(Rebate account, decimal rebateAmount)
    {
        // Update account in database, code removed for brevity
    }
}

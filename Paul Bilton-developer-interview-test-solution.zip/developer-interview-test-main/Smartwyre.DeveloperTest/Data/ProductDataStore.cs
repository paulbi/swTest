﻿using Smartwyre.DeveloperTest.Types;
using System;

namespace Smartwyre.DeveloperTest.Data;

public class ProductDataStore : IProductDataStore
{
    public Product GetProduct(string productIdentifier)
    {
        switch (productIdentifier) {
            case "1":
                {
                    return new Product
                    {
                        Id = 1,
                        Identifier = productIdentifier,
                        Price = 1.99m,
                        Uom = Guid.NewGuid().ToString(),
                        SupportedIncentives = SupportedIncentiveType.FixedRateRebate
                    };
                }
            case "2":
                {
                    return new Product
                    {
                        Id = 2,
                        Identifier = productIdentifier,
                        Price = 2.99m,
                        Uom = Guid.NewGuid().ToString(),
                        SupportedIncentives = SupportedIncentiveType.AmountPerUom
                    };
                }
            case "3":
                {
                    return new Product
                    {
                        Id = 3,
                        Identifier = productIdentifier,
                        Price = 3.99m,
                        Uom = Guid.NewGuid().ToString(),
                        SupportedIncentives = SupportedIncentiveType.FixedCashAmount
                    };
                }
            case "4":
                {
                    return new Product
                    {
                        Id = 4,
                        Identifier = productIdentifier,
                        Price = 4.99m,
                        Uom = Guid.NewGuid().ToString(),
                        SupportedIncentives = SupportedIncentiveType.FixedRateRebate | SupportedIncentiveType.AmountPerUom
                    };
                }
            case "5":
                {
                    return new Product
                    {
                        Id = 5,
                        Identifier = productIdentifier,
                        Price = 5.99m,
                        Uom = Guid.NewGuid().ToString(),
                        SupportedIncentives = SupportedIncentiveType.AmountPerUom | SupportedIncentiveType.FixedCashAmount
                    };
                }
        }

        return null;
    }
}

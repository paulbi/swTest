﻿using Smartwyre.DeveloperTest.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smartwyre.DeveloperTest.Calculators
{
    public class FixedRateRebateCalculator : IRebateCalculator
    {
        public SupportedIncentiveType IncentiveType => SupportedIncentiveType.FixedRateRebate;

        public decimal Calculate(Rebate rebate, Product product, decimal volume)
        {
            return product.Price * rebate.Percentage * volume;
        }
    }
}

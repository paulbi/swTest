﻿using Smartwyre.DeveloperTest.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smartwyre.DeveloperTest.Calculators
{
    public class AmountPerUomCalculator : IRebateCalculator
    {
        public SupportedIncentiveType IncentiveType => SupportedIncentiveType.AmountPerUom;
        public decimal Calculate(Rebate rebate, Product product, decimal volume)
        {
            return rebate.Amount * volume;
        }
    }
}

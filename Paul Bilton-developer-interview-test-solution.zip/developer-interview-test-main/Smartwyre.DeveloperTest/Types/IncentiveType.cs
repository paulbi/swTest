﻿using System;

namespace Smartwyre.DeveloperTest.Types;

[Obsolete]
public enum IncentiveType
{
    FixedRateRebate,
    AmountPerUom,
    FixedCashAmount
}

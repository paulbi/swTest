using System;
using Xunit;
using Moq;
using Smartwyre.DeveloperTest.Services;
using Smartwyre.DeveloperTest.Data;
using System.Collections.Generic;
using Smartwyre.DeveloperTest.Types;
using Smartwyre.DeveloperTest.Calculators;

namespace Smartwyre.DeveloperTest.Tests;

public class PaymentServiceTests
{
    private Mock<IRebateDataStore> _rebateDataStore;
    private Mock<IProductDataStore> _productDataStore;
    private Mock<IDictionary<SupportedIncentiveType, IRebateCalculator>> _calculators;

    private Rebate defaultFixedRateRebateObject = new Rebate() { Incentive = SupportedIncentiveType.FixedRateRebate, Amount = 100m, Percentage = 12m };
    private Product defaultFixedRateProductObject = new Product() { SupportedIncentives = SupportedIncentiveType.FixedRateRebate, Price = 10.99m };

    public PaymentServiceTests()
    {
        _rebateDataStore = new Mock<IRebateDataStore>();
        _productDataStore = new Mock<IProductDataStore>();
        _calculators = new Mock<IDictionary<SupportedIncentiveType, IRebateCalculator>>();
    }

    [Theory]
    [InlineData(1, true)]
    [InlineData(0, false)]
    public void RebateServiceReturnsResult(decimal volume, bool success)
    {
        _rebateDataStore.Setup(x => x.GetRebate(It.IsAny<string>())).Returns(defaultFixedRateRebateObject);
        _productDataStore.Setup(x => x.GetProduct(It.IsAny<string>())).Returns(defaultFixedRateProductObject);

        _calculators.Setup(x => x.ContainsKey(SupportedIncentiveType.FixedRateRebate)).Returns(true);
        _calculators.SetupGet(x => x[SupportedIncentiveType.FixedRateRebate]).Returns(new FixedRateRebateCalculator());

        var rebateService = new RebateService(_rebateDataStore.Object, _productDataStore.Object, _calculators.Object);

        var result = rebateService.Calculate(new CalculateRebateRequest() { Volume = volume });

        Assert.True(result.Success == success);
    }

    [Theory]
    [InlineData("1", SupportedIncentiveType.FixedRateRebate)]
    [InlineData("2", SupportedIncentiveType.AmountPerUom)]
    [InlineData("3", SupportedIncentiveType.FixedCashAmount)]
    public void RebateDataStoreReturnsCorrectDataResponse(string id, SupportedIncentiveType expectedType)
    {
        var rebateStore = new RebateDataStore();
        var rebateDataItem = rebateStore.GetRebate(id);

        Assert.True(rebateDataItem.Incentive == expectedType);
    }

    [Fact]
    public void RebateDataStoreIdOutofBoundsReturnsNullDataResponse()
    {
        var rebateStore = new RebateDataStore();
        var rebateDataItem = rebateStore.GetRebate("4");

        Assert.True(rebateDataItem == null);
    }

}
